# CLAUDE.md — Weapons/Ammo Data Pipeline (ex_XXX schemas)

Context notes for whoever (human or Claude) touches `db/players.js`,
`services/weapons.js`, or the gear-related indexes next. Covers what was
confirmed against real data, a real bug that was found and fixed, and
what's still an open assumption.

## Confirmed schema shapes (from real ex_230 sample rows)

**`rec_equipment_gear_assignment.gears`** (jsonb array, latest row per
`equipment_number` = current loadout):
```json
[{"gearId": 1125196038, "gearTypeId": 1026, "chargeCounting": true},
 {"gearId": 1158680873, "gearTypeId": 1017, "chargeCounting": false}]
```

**`rec_equipment_gear_charge_state.charge`** (jsonb array) — **confirmed to
contain only ONE gear's entry per row**, not a merged snapshot of all of a
player's gear:
```json
// row 1 (insert_time 1788408269593)
[{"gearId": 1125196038, "remain": 500, "gearTypeId": 1026, "chargeTypeId": 51}]
// row 2 (insert_time 1788408205592) — a DIFFERENT row for the SAME equipment_number
[{"gearId": 1158680873, "remain": 996, "gearTypeId": 1017, "chargeTypeId": 57}]
```

**`gearId` is a real, confirmed shared unique key** between the two tables
— it is the correct join key for pairing a specific weapon assignment with
its specific charge data, including when a player carries two weapons of
the identical `gearTypeId`.

**`rec_equipment_gear_event`** has no `gearId` column — only
`charge_gear_type_id`. So current-ammo (`remaining`, as opposed to `total`)
cannot be disambiguated between two identical-type weapons on one player;
both will show the same `remaining` value. This is a source-data
limitation, not a code gap.

## Bug found and fixed this session

**Symptom (pre-fix):** `gear_latest` CTE in `db/players.js` did
`DISTINCT ON (equipment_number) ... ORDER BY insert_time DESC` against
`rec_equipment_gear_charge_state`, assuming the latest row contained the
full current charge state for all of a player's gear. Since each row only
ever holds one gear's entry, this silently kept only whichever gear was
most recently updated and dropped every other weapon's ammo data
(`total: null`, `chargeTypeName: "Unknown Charge"`) with no error.

**Fix:** `gear_latest` was removed. `db/players.js` now has
`fetchChargeMap(schema)`, which:
1. Takes the last 20 charge-state rows per `equipment_number`
   (`rn <= 20` — a bound on how far back a given gear's entry might be
   buried among more-recently-updated gears; widen if needed).
2. Unnests each row's `charge` array with `LATERAL jsonb_array_elements`.
3. Keeps the newest entry per `(equipment_number, gearId)`.

`services/weapons.js`'s `buildWeapons()` was rewritten to join assignment
gears to this map **by `gearId`** instead of the previous positional
gearType-based pairing.

## Files touched this session

- `db/players.js` — removed `gear_latest`; added `fetchChargeMap` +
  `CHARGE_LATEST_SQL`; `shapePlayerBase` and both `fetchPlayers*` functions
  now thread `chargeMap` through to `buildWeapons`.
- `services/weapons.js` — `buildWeapons()` rewritten to pair by `gearId`;
  dropped the old dual-shape (`[1029]` vs `[{gearTypeId:1029}]`) tolerance
  since the real shape is confirmed as `[{gearId, gearTypeId, ...}]`.
- `create-indexes.sql` / `rollback-indexes.sql` — **revision 2**:
  `idx_rec_equipment_gear_event_eq_gt_time` re-keyed on
  `charge_gear_type_id` (was `charge_charge_type_id`); new
  `idx_rec_equipment_gear_assignment_eq_time`. No new index was needed for
  the `fetchChargeMap` fix — the existing
  `idx_rec_equipment_gear_charge_state_eq_time (equipment_number,
  insert_time DESC)` already serves its window function.
- `chargeType.js`, `dashboard.html` — unchanged this session.

## Still open / worth revisiting

- `rn <= 20` in `CHARGE_LATEST_SQL` is a guess, not a measured bound.
- `remaining` (current ammo) can't distinguish two identical-`gearTypeId`
  weapons on the same player — would need a `gearId` column added to
  `rec_equipment_gear_event` upstream to fix properly.
- Backend cache (`CACHE_TTL_MS = 3000`) decouples DB load from the 2s
  frontend poll — confirm this was the intended reading of "poll 3s
  backend / 2s frontend" if display staleness ever becomes a concern.
- `localStorage`-based exercise auto-resume falls back silently (no error
  shown) if the remembered exercise is no longer in the fetched list.

## Session: dashboard.html UI revision (theme + layout)

Only `dashboard.html` was touched. Backend/services/routes untouched.

**Theme rewrite** — replaced the dark "cyber" theme (Dracula-ish palette,
neon glow shadows, scanline overlay, flicker/pulse-glow keyframes,
gradient panels) with a flat, muted "dirty white" light theme:
- New `:root` palette: `--bg #ece7dc`, `--bg2 #e2dccd`, `--panel #f4f0e6`,
  `--line #c9c0ac`, `--fg #3a3527` (warm dark gray, not pure black),
  `--muted #847c68`; team/status accents (`--blue`, `--red`, `--green`,
  `--yellow`, `--orange`, `--purple`) desaturated so nothing glows or
  clashes against the light background.
- Removed: `body::before` scanline overlay, `pulseGlow`/`flicker`
  keyframes and every glow-style `box-shadow` (badges, buttons, dots,
  bars, `.brand .sig`, `.live`). Replaced with a single soft
  `pulseSoft` (opacity-only) animation for the two "live" indicators.
  Panels (`.team-card`, `.pcard`, `.modal`, `.stats-modal`, `#aiPanel`)
  are flat backgrounds instead of dark gradients.
- **PDF export (`exportWinnerPDF`) colors were left unchanged** — those
  are hardcoded jsPDF RGB arrays for a printed report, not part of the
  on-screen "interface" the request was scoped to.

**Layout/sizing**
- `.team-card` padding: `16px` → `18px 6px` (left/right ≈ 1/3 of the
  original 16px; top/bottom nudged up slightly to match the larger
  fonts).
- Base font size raised (`html,body` now `font-size:16px` explicit) and
  most component font-sizes bumped up 1–4px across headers, badges,
  buttons, player cards, `.kv` rows, weapon rows, stats table/cards, AI
  chat panel.
- `.modal` max-width `520px` → `680px`; `.stats-modal` `1100px` →
  `1150px`; `#aiPanel` width `440px` → `460px` — sized up to match the
  larger text.
- Player/vehicle class icons (👤/⚙) enlarged: new `.class-icon` span
  (`font-size:20px`) wraps the icon in `classIconHtml()` (used in both
  player cards and the modal's PAN ID row); the same icons next to the
  team header alive/total counts (`renderClassCounts()`) got an inline
  `font-size:20px` span too.

**HP bar** — both the player-card bar and the modal's big health bar
went from 4 discrete segments to a single thin fill bar:
- CSS: `.hbars`/`.hbars i` (4-segment) → `.hbar`/`.hbar>i` (single bar,
  `height:8px`, width driven by inline `style`); `.health-big`/`.health-big i`
  same treatment for the modal (`height:16px`).
- JS: `renderPlayers()` now computes `hpPct = healthBars/4 * 100` and
  renders one `<i>` with `width:${hpPct}%`, color class same as before
  (`hpColorClass`, falling back to `hp-killed` when `bars <= 0`).
  `healthBarHtml()` (modal) does the equivalent with an inline
  `background` color via `colorFor()`.

**Modal "Health - Status" line** — dropped the `healthBars+'/4'` prefix;
`#pmHealthStatus` now shows only the localized status text (Ready /
Wounded / Killed / Catastrophic Killed / Unknown), in both `openPlayer()`
and the live-refresh `updatePlayerModal()`.
