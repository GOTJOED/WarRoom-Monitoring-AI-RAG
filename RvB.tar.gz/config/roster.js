// config/roster.js
// Manual roster (per-exercise Blue/Red assignment override), persisted to
// roster.json. Holds the single in-memory `roster` object.

const path = require('path');
const fs = require('fs');

const ROSTER_PATH = path.join(__dirname, '..', 'roster.json');

function loadRoster() {
  try {
    return JSON.parse(fs.readFileSync(ROSTER_PATH, 'utf8'));
  } catch (err) {
    return {};
  }
}

function saveRoster(r) {
  fs.writeFileSync(ROSTER_PATH, JSON.stringify(r, null, 2), 'utf8');
}

let roster = loadRoster();

function getRosterStore() {
  return roster;
}

function setRosterStore(newRoster) {
  roster = newRoster;
  return roster;
}

function rosterFor(exerciseId) {
  if (!roster[exerciseId]) {
    roster[exerciseId] = { blue: [], red: [] };
  }
  return roster[exerciseId];
}

module.exports = {
  ROSTER_PATH,
  loadRoster,
  saveRoster,
  getRosterStore,
  setRosterStore,
  rosterFor,
};
