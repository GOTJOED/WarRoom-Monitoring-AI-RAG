// config/config.js
// Config load / save (persists across restarts).
// Holds the single in-memory `config` object other modules read from via
// getConfig(), and reassign via setConfig() after a POST /api/config.

const path = require('path');
const fs = require('fs');

const CONFIG_PATH = path.join(__dirname, '..', 'config.json');

function loadConfig() {
  const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
  return JSON.parse(raw);
}

function saveConfig(cfg) {
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2), 'utf8');
}

let config = loadConfig();

function getConfig() {
  return config;
}

function setConfig(newConfig) {
  config = newConfig;
  return config;
}

module.exports = { CONFIG_PATH, loadConfig, saveConfig, getConfig, setConfig };
