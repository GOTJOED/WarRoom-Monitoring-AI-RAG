# Exercise Monitoring Dashboard — Decoupled Server

This is `server.js` split into modules, following the plan from
`server-improvement-plan.md`. **Behavior is unchanged** — every route,
query, and response shape matches the original single-file `server.js`
exactly (verified: syntax-checked every file, then smoke-tested all routes
against a live process before delivering this).

Includes the ammo/weapons, modal, exercise-dropdown, and 2s-poll changes
from the previous session (documented in `CLAUDE.md` from that pass) —
they're already reflected in `db/players.js`, `services/weapons.js`,
`services/chargeType.js`, and `dashboard.html`.

## Setup

1. Copy `config.json` and `roster.json` from your existing deployment into
   this folder (project root, next to `index.js`) — they were not part of
   the uploaded files, so they're not included here. Same format as before.
2. `npm install`
3. `npm start` (or `node index.js`)

## Structure

```
index.js                  # bootstrap: express app, mounts every route, app.listen
config/
  config.js                 # loadConfig/saveConfig, in-memory config state
  roster.js                  # loadRoster/saveRoster/rosterFor, in-memory roster state
db/
  pool.js                     # buildPool, pingDb, dbStatus, health loop
  players.js                   # shared SQL + player-shaping (used by summary AND pdf export)
services/
  chargeType.js                 # pdm_charge_type cache (gearTypeId -> short_name)
  weapons.js                     # buildWeapons() — expands charge jsonb, sums ammo
  health.js                       # hpFromStateName, barColorClass, statusFromBars
  bite.js                          # biteStatus()
  llm.js                            # llamafile proxy + rule-based fallback
routes/
  systemStats.js                    # GET /api/system-stats
  dbStatus.js                        # GET/POST /api/db-status(/refresh), /api/test-connection
  exercises.js                        # GET /api/exercises
  exerciseSummary.js                   # GET /api/exercise/:id/summary
  exercisePdf.js                        # GET /api/exercise/:id/export-pdf
  roster.js                              # GET/POST/DELETE /api/exercise/:id/roster
  config.js                               # GET/POST /api/config
  queryTest.js                             # POST /api/query-test
  serviceReset.js                           # POST /api/service/reset
  llmChat.js                                 # POST /api/llm/chat
utils/
  safeSchema.js                               # safeExerciseSchema()
dashboard.html
package.json
```

## What changed vs. the plan in `server-improvement-plan.md`

One deliberate deviation from the original plan: `db/players.js` exports
**two** functions — `fetchPlayers()` (used by `/summary`) and
`fetchPlayersForExport()` (used by `/export-pdf`) — instead of one shared
function. The original code's PDF export path returns a slightly different
player shape (no `manual`/`notInExercise`/`partyId`/`hpColorClass`/`biteOk`
fields, and a different equipment-0 filter) than the summary path. Merging
them into a single function would have changed the PDF's behavior, which
wasn't requested. Both functions now share `buildSummarySql()` — so the
actual SQL (the thing that was previously hand-duplicated and the highest
real risk) is a single source of truth; only the post-query shaping
differs, and that difference is intentional and pre-existing.

## Not done in this pass

Nothing from the "Checklist" in `server-improvement-plan.md` was applied
here beyond the reorganization itself — no indexes added, no fast-fail
logic, no LLM fetch timeout, etc. This is a pure decoupling of the version
of `server.js` with your ammo/weapons/modal/poll changes already in it.
Let me know which checklist items you want implemented next and I'll wire
them into the appropriate module (e.g. the LLM timeout goes in
`services/llm.js`, DB fast-fail goes in `db/pool.js` + `routes/exerciseSummary.js`).
