// db/pool.js
// Pool management — small, capped pool. Rebuilt whenever config changes.
// PostgreSQL server MUST NOT be modified and must see negligible load:
// a tiny connection pool, short statement timeouts. No writes are issued.

const { Pool } = require('pg');

let pool = null;
let dbStatus = { connected: false, lastCheck: null, lastError: null };

function buildPool(cfg) {
  if (pool) {
    pool.end().catch(() => {});
  }
  pool = new Pool({
    host: cfg.db.host,
    port: cfg.db.port,
    user: cfg.db.user,
    password: cfg.db.password,
    database: cfg.db.database,
    ssl: cfg.db.ssl ? { rejectUnauthorized: false } : false,
    max: cfg.poolMax || 2,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 5000,
    statement_timeout: cfg.statementTimeoutMs || 4000,
  });
  pool.on('error', (err) => {
    dbStatus.connected = false;
    dbStatus.lastError = err.message;
  });
  return pool;
}

function getPool() {
  return pool;
}

function getDbStatus() {
  return dbStatus;
}

async function pingDb() {
  try {
    await pool.query('SELECT 1');
    dbStatus.connected = true;
    dbStatus.lastError = null;
  } catch (err) {
    dbStatus.connected = false;
    dbStatus.lastError = err.message;
  }
  dbStatus.lastCheck = new Date().toISOString();
}

let healthTimer = null;
function startHealthLoop(cfg) {
  if (healthTimer) clearInterval(healthTimer);
  pingDb();
  healthTimer = setInterval(pingDb, cfg.dbHealthCheckMs || 15000);
}

module.exports = { buildPool, getPool, getDbStatus, pingDb, startHealthLoop };
