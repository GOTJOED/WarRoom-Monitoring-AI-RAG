// db/players.js
// Single source of truth for the "latest telemetry per equipment_number"
// query and player-shaping logic. Used by BOTH the /summary route and the
// /export-pdf route.
//
// NOTE — performance: issues a DISTINCT ON scan per request for
// assignment_latest (rec_equipment_gear_assignment), plus the separate
// fetchChargeMap query below, on top of bite_latest, state_latest,
// position_latest, and event_latest's internal gear_resupply/ranked_events.
// See create-indexes.sql.
//
// CHANGED — the ammo "remaining" join key switched from
// charge_charge_type_id to charge_gear_type_id.
//
// CHANGED — gear_latest (single-row-per-equipment DISTINCT ON) was removed.
// Confirmed against real data: a row in rec_equipment_gear_charge_state
// carries only ONE gear's charge entry, not a merged snapshot of all of a
// player's gear — a player with 2 weapons can have those charge updates
// land in 2 separate rows with different insert_times. Taking "the latest
// row per equipment_number" silently dropped every gear except whichever
// was most recently updated. Replaced with fetchChargeMap(), which unnests
// `charge` and takes the latest entry per (equipment_number, gearId).
//
// CHANGED — Health/HP bars now come from a FIXED integer mapping of
// rec_equipment_state.vulnerability_state (see services/health.js),
// not the joined pdm_vulnerability_state text name — that join has been
// dropped from the query entirely.
//
// CHANGED — BITE Cfg is now a 3-state value (config_error x GPS freshness)
// instead of a forced-Error-on-no-GPS override — see services/bite.js.

const { GPS_TIMEOUT_SECONDS } = require('../utils/constants');
const POSITION_LOOKBACK_SECONDS = GPS_TIMEOUT_SECONDS + 4 * 60; // 15 min

// Kept in sync with routes/hitHistory.js's constants of the same name —
// same two rules apply here: originator sentinel codes that aren't a real
// shooter are never surfaced as an attacker, and a state row that maps to
// "Ready" (no effective damage) never counts as a real hit for either the
// receiving or the dealing side of the card-flash feature below.
const IGNORED_ORIGINATOR_IDS = [0, 208];
const READY_VULNERABILITY_STATES = [0, 6, 11];

const { getPool } = require('./pool');
const { safeExerciseSchema } = require('../utils/safeSchema');
const { teamFromPartyId } = require('../utils/teamMapping');
const { hpFromVulnerabilityState } = require('../services/health');
const { biteStatus } = require('../services/bite');
const { buildWeapons } = require('../services/weapons');
const { getChargeTypeMap } = require('../services/chargeType');
const { getGearTypeMap } = require('../services/gearType');

function buildSummarySql(schema, requireAssignState) {
  return `
    WITH bite_latest AS (
      SELECT DISTINCT ON (equipment_number) equipment_number, config_error, bite_errors
      FROM ${schema}.rec_equipment_bite
      ORDER BY equipment_number, insert_time DESC
    ),
    state_latest AS (
      SELECT DISTINCT ON (equipment_number) equipment_number, vulnerability_state,
             originator_id, insert_time AS state_insert_time
      FROM ${schema}.rec_equipment_state
      ORDER BY equipment_number, insert_time DESC
    ),
    assignment_latest AS (
      SELECT DISTINCT ON (equipment_number) equipment_number, gears
      FROM ${schema}.rec_equipment_gear_assignment
      ORDER BY equipment_number, insert_time DESC
    ),
    position_latest AS (
      SELECT DISTINCT ON (equipment_number)
        equipment_number, position_position_lon, position_position_lat, insert_time AS position_insert_time
      FROM ${schema}.rec_equipment_position
      WHERE insert_time >= ((EXTRACT(EPOCH FROM NOW()) - ${POSITION_LOOKBACK_SECONDS}) * 1000)::bigint
      ORDER BY equipment_number, insert_time DESC
    )
    SELECT
      pp.equipment_number,
      pp.party_id,
      pp.designator,
      pp.tactical_identifier,
      pty.name AS type_name,
      pty.type_class_id,
      sl.vulnerability_state,
      sl.originator_id,
      sl.state_insert_time,
      bl.config_error,
      bl.bite_errors,
      al.gears AS assignment_gears,
      pl.position_position_lon,
      pl.position_position_lat,
      EXTRACT(EPOCH FROM NOW()) - (pl.position_insert_time / 1000.0) AS position_age_seconds
    FROM ${schema}.ppm_participant pp
    LEFT JOIN ppm.ppm_type pty
           ON pty.id = pp.type_id
    LEFT JOIN state_latest sl
           ON sl.equipment_number = pp.equipment_number
    LEFT JOIN bite_latest bl
           ON bl.equipment_number = pp.equipment_number
    LEFT JOIN assignment_latest al
           ON al.equipment_number = pp.equipment_number
    LEFT JOIN position_latest pl
           ON pl.equipment_number = pp.equipment_number
    ${requireAssignState ? 'WHERE pp.assign_state = 1' : ''}
  `;
}

// charge_remain per (equipment_number, charge_gear_type_id) across the
// whole exercise schema — one query, reused for every player/weapon via a
// Map lookup instead of one query per player.
//
// Same two rules as before, still applicable, just re-keyed on
// charge_gear_type_id instead of charge_charge_type_id:
//   1. charge_remain rows can arrive out of order — take the last 10 rows
//      per (equipment_number, charge_gear_type_id), by insert_time DESC,
//      and report the MIN charge_remain among them.
//   2. A new row in rec_equipment_gear_charge_state for a given gear type
//      means a resupply just happened for THAT gear — gear_event rows
//      from before that gear's own resupply are excluded via the
//      gear_resupply cutoff join.
//
// FIXED — gear_resupply was previously computed per equipment_number only
// (latest rec_equipment_gear_charge_state row overall). Since each row
// carries just one gear's data, whichever gear happened to get a charge-
// state update most recently set the cutoff for ALL of that player's
// guns — so a second weapon with no update after that borrowed cutoff had
// every one of its rec_equipment_gear_event rows filtered out, leaving no
// ranked_events rows and no remainingMap entry (shows as "?" in the UI).
// gear_resupply is now computed per (equipment_number, gearTypeId) by
// unnesting `charge` the same way CHARGE_LATEST_SQL does, so each gun's
// events are only cut off by that gun's own last resupply.
// FIXED (again) — gear_resupply only has a row for a (equipment_number,
// gearTypeId) pair once that gear has appeared at least once in
// rec_equipment_gear_charge_state. A gear that has ammo events but has
// never had a charge-state/resupply row yet (confirmed case: equipment
// 1425, gearTypeId 1029 — present in rec_equipment_gear_event but absent
// from rec_equipment_gear_charge_state) had ALL of its events silently
// dropped by the previous INNER JOIN, since there was no gear_resupply
// row to match against at all — not a bad cutoff value, a missing one.
// Changed to a LEFT JOIN: when no resupply row exists yet for that gear
// type, no cutoff is applied and all of its events are considered.
const EVENT_LATEST_SQL = (schema) => `
  WITH gear_resupply AS (
    SELECT DISTINCT ON (equipment_number, gear_type_id)
      equipment_number, gear_type_id, insert_time AS resupply_time
    FROM (
      SELECT
        cs.equipment_number,
        cs.insert_time,
        (elem->>'gearTypeId')::int AS gear_type_id
      FROM ${schema}.rec_equipment_gear_charge_state cs,
           LATERAL jsonb_array_elements(
             CASE jsonb_typeof(cs.charge::jsonb)
               WHEN 'array'  THEN cs.charge::jsonb
               WHEN 'object' THEN jsonb_build_array(cs.charge::jsonb)
               ELSE '[]'::jsonb
             END
           ) AS elem
    ) x
    ORDER BY equipment_number, gear_type_id, insert_time DESC
  ),
  ranked_events AS (
    SELECT
      ge.equipment_number,
      ge.charge_gear_type_id,
      ge.charge_remain,
      ROW_NUMBER() OVER (
        PARTITION BY ge.equipment_number, ge.charge_gear_type_id
        ORDER BY ge.insert_time DESC
      ) AS rn
    FROM ${schema}.rec_equipment_gear_event ge
    LEFT JOIN gear_resupply gr
      ON gr.equipment_number = ge.equipment_number
     AND gr.gear_type_id = ge.charge_gear_type_id
    WHERE gr.resupply_time IS NULL OR ge.insert_time >= gr.resupply_time
  )
  SELECT equipment_number, charge_gear_type_id, MIN(charge_remain) AS charge_remain
  FROM ranked_events
  WHERE rn <= 10
  GROUP BY equipment_number, charge_gear_type_id
`;

async function fetchRemainingMap(schema) {
  const { rows } = await getPool().query(EVENT_LATEST_SQL(schema));
  const map = new Map();
  rows.forEach((r) => {
    map.set(`${r.equipment_number}|${r.charge_gear_type_id}`, r.charge_remain);
  });
  return map;
}

// Per-(equipment_number, gearId) latest total ammo + chargeTypeId, across
// the whole exercise schema — one query, reused via a Map lookup.
// rec_equipment_gear_charge_state rows carry only ONE gear's charge entry
// each (confirmed against real data), so a naive "latest row per
// equipment_number" silently drops every other gear on a multi-weapon
// player. This instead looks at the last 20 rows per equipment_number
// (rn <= 20 — a bound on how far back a given gearId's charge entry might
// be buried; widen if a player can go many updates without one of their
// gears appearing), unnests each row's `charge` array, and keeps the
// newest entry per gearId.
//
// DEFENSIVE: `charge` is not reliably an array on every row — some rows
// store a bare object (e.g. {"gearId":...}) instead of [{"gearId":...}].
// jsonb_array_elements() errors ("cannot extract elements from an object")
// on those, so each row is normalized to an array first: object → wrapped
// in jsonb_build_array, array → used as-is, anything else (null, scalar,
// malformed string) → empty array so it's skipped rather than erroring.
//
// DEFENSIVE (2): confirmed a single row's `charge` array can itself
// contain two entries for the same gearId/gearTypeId/chargeTypeId that
// differ only in `remain` (observed cause: firing decrements remain by 1
// on one entry, then the gear reconnects and a second entry for the same
// gear appears in the same insert reporting the reset/max value). Per
// confirmed rule, the FIRST such entry in the array is authoritative and
// the rest are discarded — WITH ORDINALITY tags each element with its
// array position, and the outer DISTINCT ON's ORDER BY breaks same-
// insert_time ties by ordinality ASC (lowest/first array position wins).
const CHARGE_LATEST_SQL = (schema) => `
  WITH charge_recent AS (
    SELECT equipment_number, insert_time,
           CASE jsonb_typeof(charge::jsonb)
             WHEN 'array'  THEN charge::jsonb
             WHEN 'object' THEN jsonb_build_array(charge::jsonb)
             ELSE '[]'::jsonb
           END AS charge_arr,
           ROW_NUMBER() OVER (PARTITION BY equipment_number ORDER BY insert_time DESC) AS rn
    FROM ${schema}.rec_equipment_gear_charge_state
  ),
  charge_unnested AS (
    SELECT
      cr.equipment_number,
      cr.insert_time,
      ord,
      (elem->>'gearId')::bigint AS gear_id,
      (elem->>'chargeTypeId')::int AS charge_type_id,
      NULLIF(elem->>'remain', '')::numeric AS remain
    FROM charge_recent cr,
         LATERAL jsonb_array_elements(cr.charge_arr) WITH ORDINALITY AS t(elem, ord)
    WHERE cr.rn <= 20
  )
  SELECT DISTINCT ON (equipment_number, gear_id)
    equipment_number, gear_id, charge_type_id, remain
  FROM charge_unnested
  ORDER BY equipment_number, gear_id, insert_time DESC, ord ASC
`;

async function fetchChargeMap(schema) {
  const { rows } = await getPool().query(CHARGE_LATEST_SQL(schema));
  const map = new Map();
  rows.forEach((r) => {
    map.set(`${r.equipment_number}|${r.gear_id}`, {
      chargeTypeId: r.charge_type_id,
      total: r.remain === null ? null : Number(r.remain),
    });
  });
  return map;
}

// Sums `remaining` across a player's weapons for the compact card-level
// ammo badge (low/empty-ammo styling). Detailed per-weapon remaining/total
// is only shown in the player modal via the `weapons` array itself.
function cardAmmoFromWeapons(weapons) {
  if (!weapons.length) return null;
  return weapons.reduce((sum, w) => sum + (typeof w.remaining === 'number' ? w.remaining : 0), 0);
}

// ppm.ppm_type.type_class_id: 3 = Human, 5 = Apache, 7 or 8 = Vehicle.
// Returns one of 'Human' | 'Apache' | 'Vehicle' | null (unmapped id).
function classFromTypeClassId(typeClassId) {
  switch (typeClassId) {
    case 3: return 'Human';
    case 5: return 'Apache';
    case 7:
    case 8: return 'Vehicle';
    default: return null;
  }
}

// "No GPS" unless both coordinates are present AND the latest position
// row is fresher than GPS_TIMEOUT_SECONDS (server-side age, see SQL above).
function isNoGps(r) {
  const hasFix = r.position_position_lon !== null && r.position_position_lon !== undefined
    && r.position_position_lat !== null && r.position_position_lat !== undefined;
  const age = r.position_age_seconds;
  const fresh = age !== null && age !== undefined && Number(age) < GPS_TIMEOUT_SECONDS;
  return !(hasFix && fresh);
}

function shapePlayerBase(r, cfg, ex, gearTypeMap, chargeTypeMap, remainingMap, chargeMap) {
  // vulnerability_state 10 (Near Miss) gets the same health-bar count/color
  // as Light Damage (3 bars) per the fixed mapping — only the displayed
  // status label differs (frontend appends " (Near Miss)" using the
  // nearMiss flag below), now derived straight from the raw integer
  // instead of a joined name string.
  const isNearMiss = r.vulnerability_state === 10;
  const hp = hpFromVulnerabilityState(r.vulnerability_state);
  const weapons = buildWeapons(r.assignment_gears, r.equipment_number, gearTypeMap, chargeTypeMap, remainingMap, chargeMap);
  const noGps = isNoGps(r);
  // BITE Cfg is now the 3-state combined value (config_error + GPS
  // freshness) — see services/bite.js for the exact rules and flagged gap.
  const bite = biteStatus(r.config_error, noGps);

  // Manual roster (blue/red only) overrides the fixed party_id mapping;
  // otherwise team is derived from the fixed 1=OC / 2=RED / 3=BLUE scheme.
  let team = teamFromPartyId(r.party_id);
  let manual = false;
  if (ex.blue.includes(r.equipment_number)) {
    team = 'blue';
    manual = true;
  } else if (ex.red.includes(r.equipment_number)) {
    team = 'red';
    manual = true;
  }

  // Card-flash feature: lastHitAt is the raw insert_time of this player's
  // latest rec_equipment_state row, exposed purely so the frontend can
  // detect "a new state row landed since the last poll" by comparing it
  // poll-to-poll (the backend has no memory of the previous poll itself).
  // lastHitIsReal / lastHitOriginatorId mirror the hit-history route's
  // filtering so a Ready/no-effect state or a sentinel originator never
  // triggers a flash on either end.
  const lastHitIsReal = r.vulnerability_state !== null && r.vulnerability_state !== undefined
    && !READY_VULNERABILITY_STATES.includes(r.vulnerability_state);
  const originatorIsAttributable = lastHitIsReal
    && r.originator_id !== null && r.originator_id !== undefined
    && !IGNORED_ORIGINATOR_IDS.includes(r.originator_id)
    && r.originator_id !== r.equipment_number;

  return {
    hp, bite, weapons, team, manual, noGps, nearMiss: isNearMiss,
    typeClass: classFromTypeClassId(r.type_class_id),
    lastHitAt: (r.state_insert_time === null || r.state_insert_time === undefined) ? null : Number(r.state_insert_time),
    lastHitIsReal,
    lastHitOriginatorId: originatorIsAttributable ? r.originator_id : null,
  };
}

// ---------------------------------------------------------------------
// Per-exercise response cache. Frontend can poll at whatever cadence it
// wants (currently 2s); this caps how often the DB actually gets hit for
// a given exercise to CACHE_TTL_MS (3s), regardless of how many clients/
// tabs are polling. A concurrent-request lock prevents a thundering herd
// of simultaneous cache-miss requests from all independently re-querying
// the DB at once.
// ---------------------------------------------------------------------
const CACHE_TTL_MS = 2000;
const summaryCache = new Map(); // exerciseId -> { data, fetchedAt, inFlight }

async function getCachedSummary(exerciseId, computeFn) {
  const now = Date.now();
  const cached = summaryCache.get(exerciseId);

  if (cached && (now - cached.fetchedAt) < CACHE_TTL_MS) {
    return cached.data;
  }
  if (cached && cached.inFlight) {
    return cached.inFlight;
  }

  const inFlight = computeFn()
    .then((data) => {
      summaryCache.set(exerciseId, { data, fetchedAt: Date.now(), inFlight: null });
      return data;
    })
    .catch((err) => {
      summaryCache.delete(exerciseId);
      throw err;
    });

  summaryCache.set(exerciseId, { data: cached ? cached.data : null, fetchedAt: cached ? cached.fetchedAt : 0, inFlight });
  return inFlight;
}

// Fetches and shapes the full player list for an exercise, including the
// manual-roster-only "not in exercise" entries. Returns { players, blue,
// red, unknownTeam } — used directly by the /summary route. `unknownTeam`
// also carries OC personnel (team === 'oc'), reusing the existing
// "unknown team" box on the dashboard rather than a dedicated OC section —
// each player's own `team` field still reads 'oc' correctly for the modal.
async function fetchPlayersUncached(exerciseId, cfg, ex) {
  const schema = safeExerciseSchema(exerciseId);
  const sql = buildSummarySql(schema, cfg.requireAssignState);

  const [{ rows }, chargeTypeMap, gearTypeMap, remainingMap, chargeMap] = await Promise.all([
    getPool().query(sql),
    getChargeTypeMap(),
    getGearTypeMap(),
    fetchRemainingMap(schema),
    fetchChargeMap(schema),
  ]);

  const seenEquipmentNumbers = new Set(rows.map((r) => r.equipment_number));
  const manualOnlyNumbers = [...ex.blue, ...ex.red].filter(
    (eq) => !seenEquipmentNumbers.has(eq)
  );

  const players = rows
    .filter((r) => {
      if (r.equipment_number === 0) {
        return ex.blue.includes(0) || ex.red.includes(0);
      }
      return true;
    })
    .map((r) => {
      const { hp, bite, weapons, team, manual, noGps, nearMiss, typeClass, lastHitAt, lastHitIsReal, lastHitOriginatorId } = shapePlayerBase(r, cfg, ex, gearTypeMap, chargeTypeMap, remainingMap, chargeMap);

      return {
        equipmentNumber: r.equipment_number,
        team,
        manual,
        notInExercise: false,
        partyId: r.party_id,
        designator: r.designator,
        tacticalIdentifier: r.tactical_identifier,
        typeName: r.type_name || 'Unknown',
        typeClass,
        ammo: cardAmmoFromWeapons(weapons),
        weapons,
        healthBars: hp.bars,
        hpColorClass: hp.colorClass,
        status: hp.status,
        nearMiss,
        biteOk: bite.ok,
        biteLabel: bite.label,
        noGps,
        lastHitAt,
        lastHitIsReal,
        lastHitOriginatorId,
      };
    });

  for (const eq of manualOnlyNumbers) {
    players.push({
      equipmentNumber: eq,
      team: ex.blue.includes(eq) ? 'blue' : 'red',
      manual: true,
      notInExercise: true,
      partyId: null,
      designator: null,
      tacticalIdentifier: null,
      typeName: null,
      typeClass: null,
      ammo: null,
      weapons: [],
      healthBars: null,
      hpColorClass: null,
      status: null,
      biteOk: null,
      biteLabel: null,
      noGps: null,
      lastHitAt: null,
      lastHitIsReal: false,
      lastHitOriginatorId: null,
    });
  }

  const blue = players.filter((p) => p.team === 'blue');
  const red = players.filter((p) => p.team === 'red');
  const unknownTeam = players.filter((p) => p.team === 'unknown' || p.team === 'oc');

  return { players, blue, red, unknownTeam };
}

async function fetchPlayers(exerciseId, cfg, ex) {
  return getCachedSummary(exerciseId, () => fetchPlayersUncached(exerciseId, cfg, ex));
}

// Simplified variant for /export-pdf: no manual-only "not in exercise"
// padding, and player shape trimmed to what the PDF actually renders.
// NOT cached — an explicit export action should always reflect current data.
async function fetchPlayersForExport(exerciseId, cfg, ex) {
  const schema = safeExerciseSchema(exerciseId);
  const sql = buildSummarySql(schema, cfg.requireAssignState);

  const [{ rows }, chargeTypeMap, gearTypeMap, remainingMap, chargeMap] = await Promise.all([
    getPool().query(sql),
    getChargeTypeMap(),
    getGearTypeMap(),
    fetchRemainingMap(schema),
    fetchChargeMap(schema),
  ]);

  const players = rows
    .filter((r) => r.equipment_number !== 0 || ex.blue.includes(0) || ex.red.includes(0))
    .map((r) => {
      const { hp, bite, weapons, team, noGps, nearMiss, typeClass } = shapePlayerBase(r, cfg, ex, gearTypeMap, chargeTypeMap, remainingMap, chargeMap);

      return {
        equipmentNumber: r.equipment_number,
        team,
        designator: r.designator,
        tacticalIdentifier: r.tactical_identifier,
        typeName: r.type_name || 'Unknown',
        typeClass,
        ammo: cardAmmoFromWeapons(weapons),
        weapons,
        healthBars: hp.bars,
        status: hp.status,
        nearMiss,
        biteLabel: bite.label,
        noGps,
      };
    });

  return players;
}

module.exports = { fetchPlayers, fetchPlayersForExport };
