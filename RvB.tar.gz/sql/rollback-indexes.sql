-- ============================================================================
-- Rollback script — REVISION 2 — drops everything in create-indexes.sql,
-- PLUS the obsolete revision-1 gear_event index if you created it before
-- this changeover (it's keyed on charge_charge_type_id, which the query no
-- longer uses — safe to drop regardless of whether you ran revision 1).
-- Safe to run even if some/none of these exist (IF EXISTS).
-- DROP INDEX CONCURRENTLY does not lock out reads/writes — do not wrap in
-- a transaction.
-- ============================================================================

-- Obsolete revision-1 index (charge_charge_type_id key) — drop if present:
DROP INDEX CONCURRENTLY IF EXISTS ex_230.idx_rec_equipment_gear_event_eq_ct_time;

-- Current revision-2 indexes:
DROP INDEX CONCURRENTLY IF EXISTS ex_230.idx_rec_equipment_position_eq_time;
DROP INDEX CONCURRENTLY IF EXISTS ex_230.idx_rec_equipment_gear_event_eq_gt_time;
DROP INDEX CONCURRENTLY IF EXISTS ex_230.idx_rec_equipment_gear_charge_state_eq_time;
DROP INDEX CONCURRENTLY IF EXISTS ex_230.idx_rec_equipment_gear_assignment_eq_time;
DROP INDEX CONCURRENTLY IF EXISTS ex_230.idx_rec_equipment_bite_eq_time;
DROP INDEX CONCURRENTLY IF EXISTS ex_230.idx_rec_equipment_state_eq_time;
DROP INDEX CONCURRENTLY IF EXISTS ex_230.idx_ppm_participant_assign_state;
DROP INDEX CONCURRENTLY IF EXISTS ex_230.idx_rec_equipment_state_originator_id_time;

-- Verify all gone:
--   SELECT indexname FROM pg_indexes
--   WHERE schemaname = 'ex_230' AND indexname LIKE 'idx_%';
-- (should return zero rows)
-- ============================================================================
