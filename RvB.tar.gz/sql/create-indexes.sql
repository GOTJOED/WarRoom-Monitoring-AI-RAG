-- ============================================================================
-- Index creation script — PostgreSQL 9.6.5 — REVISION 2
-- Reflects the rec_equipment_gear_assignment changeover.
--
-- CHANGES FROM REVISION 1:
--   - idx_rec_equipment_gear_event_eq_ct_time: join key changed from
--     charge_charge_type_id to charge_gear_type_id (the EVENT_LATEST_SQL
--     window function now partitions on charge_gear_type_id). If you
--     already created the old version of this index, it no longer serves
--     this query — see rollback-indexes.sql to drop it.
--   - NEW: idx_rec_equipment_gear_assignment_eq_time, for the new
--     assignment_latest DISTINCT ON query.
--   - Unchanged: gear_charge_state, bite, state, position, ppm_participant
--     indexes — still used exactly as before.
--
-- Run per exercise schema (replace ex_230 with the actual schema each time,
-- or generate dynamically — see note at bottom, same as revision 1).
--
-- CONCURRENTLY: builds without holding a write-blocking lock — required
-- since telemetry is being written live. Cannot run inside a transaction
-- block — run each statement individually.
-- IF NOT EXISTS: safe to re-run.
-- ============================================================================

-- 1. HIGHEST PRIORITY — confirmed 4.6M rows in ex_230.
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_rec_equipment_position_eq_time
  ON ex_230.rec_equipment_position (equipment_number, insert_time DESC);

-- 2. REVISED KEY — now charge_gear_type_id, not charge_charge_type_id.
--    Needed for the EVENT_LATEST_SQL window-function query (ammo remaining).
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_rec_equipment_gear_event_eq_gt_time
  ON ex_230.rec_equipment_gear_event (equipment_number, charge_gear_type_id, insert_time DESC);

-- 3. Used by gear_latest (total ammo + charge type lookup) AND
--    gear_resupply (the resupply-cutoff join in EVENT_LATEST_SQL).
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_rec_equipment_gear_charge_state_eq_time
  ON ex_230.rec_equipment_gear_charge_state (equipment_number, insert_time DESC);

-- 4. NEW — assignment_latest (weapon list source).
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_rec_equipment_gear_assignment_eq_time
  ON ex_230.rec_equipment_gear_assignment (equipment_number, insert_time DESC);

-- 5. BITE status lookup.
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_rec_equipment_bite_eq_time
  ON ex_230.rec_equipment_bite (equipment_number, insert_time DESC);

-- 6. Vulnerability/health-state lookup.
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_rec_equipment_state_eq_time
  ON ex_230.rec_equipment_state (equipment_number, insert_time DESC);

-- 7. LOWER PRIORITY — small base table, likely already fast.
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_ppm_participant_assign_state
  ON ex_230.ppm_participant (assign_state)
  WHERE assign_state = 1;

-- 8. NEW — hit-history lookup (routes/hitHistory.js) queries
--    WHERE equipment_number = $1 OR originator_id = $1. Index #6 above
--    already covers the equipment_number side; this covers originator_id
--    so both sides of the OR can use an index scan instead of one side
--    falling back to a sequential scan.
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_rec_equipment_state_originator_id_time
  ON ex_230.rec_equipment_state (originator_id, insert_time DESC);

-- ============================================================================
-- Verify after creation:
--   SELECT indexname, indexdef FROM pg_indexes WHERE schemaname = 'ex_230';
--
-- Confirm the planner uses them, e.g. for the new assignment query:
--   EXPLAIN (ANALYZE, BUFFERS)
--   SELECT DISTINCT ON (equipment_number) equipment_number, gears
--   FROM ex_230.rec_equipment_gear_assignment
--   ORDER BY equipment_number, insert_time DESC;
-- Look for "Index Scan" instead of "Seq Scan" + "Sort".
--
-- Applying to every exercise schema — generate dynamically instead of
-- hand-editing per schema:
--
--   SELECT format(
--     'CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_%1$s_rec_equipment_position_eq_time ON %1$s.rec_equipment_position (equipment_number, insert_time DESC);',
--     schema_name
--   )
--   FROM information_schema.schemata
--   WHERE schema_name LIKE 'ex\_%' ESCAPE '\';
--
-- Repeat the format() pattern for the other six tables. Test on the clone
-- first regardless.
-- ============================================================================
