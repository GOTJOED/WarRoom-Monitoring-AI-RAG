// stats/store.js
// Per-exercise recording session state + last-computed stats result.
// Same pattern as config/config.js and config/roster.js: flat JSON file on
// disk, loaded once into memory, read/written through accessor functions.
// Deliberately NOT written into the restricted Postgres DB.

const path = require('path');
const fs = require('fs');

const STATS_PATH = path.join(__dirname, '..', 'stats-sessions.json');

function loadSessions() {
  try {
    return JSON.parse(fs.readFileSync(STATS_PATH, 'utf8'));
  } catch (err) {
    return {};
  }
}

function saveSessions(s) {
  fs.writeFileSync(STATS_PATH, JSON.stringify(s, null, 2), 'utf8');
}

let sessions = loadSessions();

// Shape per exerciseId:
//   {
//     recording: boolean,
//     startTime: epoch-ms | null,       // only meaningful while recording
//     lastResult: {...} | null,          // last COMPLETED (>=10min) session's computed stats
//     lastComputedAt: epoch-ms | null,
//     lastWindow: { start, stop } | null // the window lastResult covers
//   }
function getSession(exerciseId) {
  if (!sessions[exerciseId]) {
    sessions[exerciseId] = { recording: false, startTime: null, lastResult: null, lastComputedAt: null, lastWindow: null };
  }
  return sessions[exerciseId];
}

function persist() {
  saveSessions(sessions);
}

module.exports = { getSession, persist };
