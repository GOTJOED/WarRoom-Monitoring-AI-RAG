// routes/llmChat.js
// POST /api/llm/chat { message, context } -> { reply, source: 'llamafile'|'rule-fallback' }

const express = require('express');
const { getLlmReply } = require('../services/llm');
const { getConfig } = require('../config/config');

const router = express.Router();

router.post('/api/llm/chat', async (req, res) => {
  const { message, context } = req.body || {};
  if (!message) return res.status(400).json({ error: 'Missing message' });

  const result = await getLlmReply(message, context, getConfig());
  res.json(result);
});

module.exports = router;
