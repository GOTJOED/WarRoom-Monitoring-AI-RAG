// routes/serviceReset.js
// POST /api/service/reset — re-pings DB, reloads config/roster from disk

const express = require('express');
const { getDbStatus, pingDb, buildPool } = require('../db/pool');
const { loadConfig, getConfig, setConfig } = require('../config/config');
const { loadRoster, setRosterStore } = require('../config/roster');

const router = express.Router();

router.post('/api/service/reset', async (req, res) => {
  try {
    await pingDb();
    try { setConfig(loadConfig()); } catch {}
    try { setRosterStore(loadRoster()); } catch {}
    const dbStatus = getDbStatus();
    if (!dbStatus.connected) {
      try { buildPool(getConfig()); await pingDb(); } catch {}
    }
    res.json({ ok: true, dbStatus: getDbStatus(), serverTime: new Date().toISOString(), message: 'Service repulled — DB re-pinged, config reloaded' });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message, dbStatus: getDbStatus() });
  }
});

module.exports = router;
