// routes/exerciseSummary.js
// GET /api/exercise/:id/summary — the scoreboard payload

const express = require('express');
const { safeExerciseSchema } = require('../utils/safeSchema');
const { fetchPlayers } = require('../db/players');
const { getConfig } = require('../config/config');
const { rosterFor } = require('../config/roster');

const router = express.Router();

router.get('/api/exercise/:id/summary', async (req, res) => {
  let schema;
  try {
    schema = safeExerciseSchema(req.params.id);
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }

  try {
    const cfg = getConfig();
    const ex = rosterFor(req.params.id);
    const { blue, red, unknownTeam } = await fetchPlayers(req.params.id, cfg, ex);

    res.json({
      exerciseId: req.params.id,
      counts: {
        blueTotal: blue.length,
        blueAlive: blue.filter((p) => p.status && p.status !== 'Killed').length,
        redTotal: red.length,
        redAlive: red.filter((p) => p.status && p.status !== 'Killed').length,
      },
      blue,
      red,
      unknownTeam,
    });
  } catch (err) {
    res.status(500).json({ error: err.message, schema });
  }
});

module.exports = router;
