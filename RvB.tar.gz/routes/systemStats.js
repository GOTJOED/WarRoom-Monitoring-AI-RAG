// routes/systemStats.js
// GET /api/system-stats

const express = require('express');
const si = require('systeminformation');

const router = express.Router();

router.get('/api/system-stats', async (req, res) => {
  try {
    const [cpu, mem, fsSize] = await Promise.all([
      si.currentLoad(),
      si.mem(),
      si.fsSize(),
    ]);
    const rootDisk = fsSize.find((d) => d.mount === '/' || d.mount === 'C:') || fsSize[0];
    res.json({
      cpuPct: Math.round(cpu.currentLoad),
      memPct: Math.round((mem.active / mem.total) * 100),
      diskPct: rootDisk ? Math.round(rootDisk.use) : null,
      serverTime: new Date().toISOString(),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
