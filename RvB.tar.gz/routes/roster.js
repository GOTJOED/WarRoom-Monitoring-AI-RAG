// routes/roster.js
// GET/POST/DELETE /api/exercise/:id/roster — manual Blue/Red override

const express = require('express');
const { rosterFor, getRosterStore, saveRoster } = require('../config/roster');

const router = express.Router();

router.get('/api/exercise/:id/roster', (req, res) => {
  res.json(rosterFor(req.params.id));
});

router.post('/api/exercise/:id/roster', (req, res) => {
  const { team, equipmentNumber } = req.body;
  if (team !== 'blue' && team !== 'red') {
    return res.status(400).json({ ok: false, error: "team must be 'blue' or 'red'" });
  }
  const eq = Number(equipmentNumber);
  if (!Number.isInteger(eq)) {
    return res.status(400).json({ ok: false, error: 'equipmentNumber must be an integer' });
  }
  const ex = rosterFor(req.params.id);
  ex.blue = ex.blue.filter((n) => n !== eq);
  ex.red = ex.red.filter((n) => n !== eq);
  ex[team].push(eq);
  saveRoster(getRosterStore());
  res.json({ ok: true, roster: ex });
});

router.delete('/api/exercise/:id/roster', (req, res) => {
  const { team, equipmentNumber } = req.body;
  const eq = Number(equipmentNumber);
  const ex = rosterFor(req.params.id);
  if (team === 'blue' || team === 'red') {
    ex[team] = ex[team].filter((n) => n !== eq);
  }
  saveRoster(getRosterStore());
  res.json({ ok: true, roster: ex });
});

module.exports = router;
