// routes/exercisePdf.js
// GET /api/exercise/:id/export-pdf — server-side "winner" combat report PDF

const express = require('express');
const { fetchPlayersForExport } = require('../db/players');
const { getConfig } = require('../config/config');
const { rosterFor } = require('../config/roster');

let PDFDocument;
try {
  PDFDocument = require('pdfkit');
} catch (e) {
  console.warn("[WARN] 'pdfkit' module not found. Server-side PDF export will fail until you run: npm install pdfkit");
}

const router = express.Router();

router.get('/api/exercise/:id/export-pdf', async (req, res) => {
  if (!PDFDocument) {
    return res.status(500).json({ error: "pdfkit module not installed. Run: 'npm install pdfkit' on the server." });
  }

  try {
    const exerciseId = req.params.id;
    const cfg = getConfig();
    const ex = rosterFor(exerciseId);
    const players = await fetchPlayersForExport(exerciseId, cfg, ex);

    const blue = players.filter(p => p.team === 'blue');
    const red = players.filter(p => p.team === 'red');
    const blueAlive = blue.filter(p => p.status && p.status !== 'Killed').length;
    const redAlive = red.filter(p => p.status && p.status !== 'Killed').length;
    let winnerTeam = blueAlive >= redAlive ? 'blue' : 'red';
    if (blueAlive === 0) winnerTeam = 'red';
    if (redAlive === 0) winnerTeam = 'blue';
    const winnerPlayers = winnerTeam === 'blue' ? blue : red;
    const finalList = winnerPlayers.filter(p => p.status !== 'Killed');
    const list = finalList.length ? finalList : winnerPlayers;

    // Build the PDF
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="winner-${winnerTeam}-${exerciseId}.pdf"`);

    const doc = new PDFDocument({ margin: 40 });
    doc.pipe(res);

    doc.font('Helvetica-Bold').fontSize(18).fillColor('#000000').text(`EXERCISE DRACULA // COMBAT REPORT`, { align: 'center' });
    doc.font('Helvetica').fontSize(10).fillColor('#555555').text(`EXERCISE ID: ${exerciseId} | TIMESTAMP: ${new Date().toISOString()}`, { align: 'center' });
    doc.moveDown(1.5);

    const winColor = winnerTeam === 'blue' ? '#007BFF' : '#DC3545';
    doc.font('Helvetica-Bold').fontSize(14).fillColor(winColor).text(`VICTORY: ${winnerTeam.toUpperCase()} TEAM`, { align: 'center' });
    doc.font('Helvetica').fontSize(12).fillColor('#000000').text(`SURVIVORS STANDING`, { align: 'center' });
    doc.moveDown(1.5);

    doc.font('Helvetica-Bold').fontSize(12).fillColor('#333333').text(`TELEMETRY ROSTER:`);
    doc.moveDown(0.5);

    // List out operators
    list.forEach(p => {
      doc.font('Helvetica-Bold').fontSize(11).fillColor('#000000').text(`Operator #${p.equipmentNumber} (${p.team.toUpperCase()})`);
      doc.font('Helvetica').fontSize(10).fillColor('#444444').text(`Status: ${p.status} | Health: ${p.healthBars}/4 | Ammo: ${p.ammo || 'N/A'} | BITE: ${p.biteLabel}`);
      if (p.typeName) {
        doc.font('Helvetica').fontSize(10).fillColor('#666666').text(`Type: ${p.typeName}`);
      }
      doc.moveDown(0.8);
    });

    doc.end();

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
