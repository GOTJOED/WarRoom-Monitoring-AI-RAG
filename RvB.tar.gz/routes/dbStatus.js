// routes/dbStatus.js
// GET  /api/db-status
// POST /api/db-status/refresh
// POST /api/test-connection

const express = require('express');
const { getPool, getDbStatus, pingDb } = require('../db/pool');

const router = express.Router();

router.get('/api/db-status', (req, res) => {
  res.json(getDbStatus());
});

router.post('/api/db-status/refresh', async (req, res) => {
  await pingDb();
  res.json(getDbStatus());
});

router.post('/api/test-connection', async (req, res) => {
  try {
    const start = Date.now();
    await getPool().query('SELECT 1');
    res.json({ ok: true, latencyMs: Date.now() - start });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

module.exports = router;
