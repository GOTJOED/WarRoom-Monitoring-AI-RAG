// routes/queryTest.js
// POST /api/query-test — ad-hoc read-only query verification tab

const express = require('express');
const { getPool } = require('../db/pool');

const router = express.Router();

router.post('/api/query-test', async (req, res) => {
  const { query } = req.body;
  if (!query || typeof query !== 'string') {
    return res.status(400).json({ error: 'Missing query' });
  }
  const trimmed = query.trim().replace(/;+\s*$/, '');
  if (!/^select\s/i.test(trimmed)) {
    return res.status(400).json({ error: 'Only SELECT statements are allowed here.' });
  }
  if (/\b(insert|update|delete|drop|alter|truncate|grant|revoke|create)\b/i.test(trimmed)) {
    return res.status(400).json({ error: 'Only read-only SELECT statements are allowed here.' });
  }
  try {
    const start = Date.now();
    const result = await getPool().query(`${trimmed} LIMIT 200`);
    res.json({
      ok: true,
      latencyMs: Date.now() - start,
      rowCount: result.rowCount,
      fields: result.fields.map((f) => f.name),
      rows: result.rows,
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

module.exports = router;
