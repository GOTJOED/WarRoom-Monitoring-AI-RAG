// routes/exercises.js
// GET /api/exercises

const express = require('express');
const { getPool } = require('../db/pool');

const router = express.Router();

router.get('/api/exercises', async (req, res) => {
  const sql = `
    SELECT e.id, e.name, e.description, e.created, e.begin_time,
           e.exercise_state_id, es.name AS state_name
    FROM exm.exercise e
    LEFT JOIN exm.exercise_state es ON es.id = e.exercise_state_id
    ORDER BY e.created DESC
  `;
  try {
    const { rows } = await getPool().query(sql);
    res.json(
      rows.map((r) => ({
        id: r.id,
        name: r.name,
        description: r.description,
        created: r.created,
        beginTime: r.begin_time,
        stateId: r.exercise_state_id,
        stateName: r.state_name,
        isActive: r.exercise_state_id === 2,
      }))
    );
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
