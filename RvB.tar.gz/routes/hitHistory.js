// routes/hitHistory.js
// GET /api/exercise/:id/player/:equipmentNumber/hits
//
// "Who shot who" history for one player, scoped to their current session:
// only events (caused or received) since the LATEST of —
//   1. this equipment's own vulnerability_state last being exactly 0
//      (Combat Ready) — i.e. the start of their current life, and
//   2. the first time AFTER that respawn that BOTH their BITE Cfg cleared
//      (config_error = false) AND a GPS fix was received — i.e. the point
//      their systems check actually passed.
// If either check (BITE or GPS) has never passed since the last respawn,
// no history is returned at all — a unit with an unresolved BITE error or
// that has never reported GPS shouldn't show hits yet. Newest first.
// Read-only.
//
// Needs a companion index on originator_id to keep the OR cheap at scale —
// see idx_rec_equipment_state_originator_id_time in sql/create-indexes.sql.

const express = require('express');
const { getPool } = require('../db/pool');
const { safeExerciseSchema } = require('../utils/safeSchema');
const { hpFromVulnerabilityState } = require('../services/health');

const router = express.Router();

const HIT_HISTORY_LIMIT = 30;

// originator_id values that aren't a real shooter (environment / no-fire
// sentinel codes for this exercise) — hits attributed to these are excluded
// entirely, in both directions (caused and received).
const IGNORED_ORIGINATOR_IDS = [0, 208];

// vulnerability_state values that map to "Ready" (bars=4, no effective
// damage) per services/health.js's VULN_STATE_TO_BARS — hits that didn't
// actually change status are excluded from the displayed list.
const READY_VULNERABILITY_STATES = [0, 6, 11];

// Respawn/reset basis — strictly state 0 (Combat Ready), NOT the full
// READY_VULNERABILITY_STATES set above. States 6 (Weapon System Damage)
// and 11 (Hit with No Effect) also display 4 HP bars, but neither is an
// actual "came back online" event — 11 in particular is just a shot that
// happened to do nothing, which could otherwise fire repeatedly and keep
// pushing the cutoff forward, hiding real prior history. Only a genuine
// state-0 row marks the start of a new life.
const RESPAWN_VULNERABILITY_STATE = 0;

// Sentinel used when a required check (BITE-ok or GPS) has never happened
// since the last respawn — pushes the effective cutoff past any real
// insert_time, so history stays empty until that check actually passes.
const NEVER_SENTINEL = '9223372036854775807'; // max bigint

router.get('/api/exercise/:id/player/:equipmentNumber/hits', async (req, res) => {
  let schema;
  try {
    schema = safeExerciseSchema(req.params.id);
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }

  const eq = Number(req.params.equipmentNumber);
  if (!Number.isInteger(eq)) {
    return res.status(400).json({ error: 'equipmentNumber must be an integer' });
  }

  const sql = `
    WITH last_ready AS (
      SELECT MAX(insert_time) AS t
      FROM ${schema}.rec_equipment_state
      WHERE equipment_number = $1
        AND vulnerability_state = ${RESPAWN_VULNERABILITY_STATE}
    ),
    first_bite_ok AS (
      SELECT MIN(b.insert_time) AS t
      FROM ${schema}.rec_equipment_bite b
      CROSS JOIN last_ready lr
      WHERE b.equipment_number = $1
        AND b.config_error = false
        AND (lr.t IS NULL OR b.insert_time > lr.t)
    ),
    first_gps AS (
      SELECT MIN(p.insert_time) AS t
      FROM ${schema}.rec_equipment_position p
      CROSS JOIN last_ready lr
      WHERE p.equipment_number = $1
        AND p.position_position_lon IS NOT NULL
        AND p.position_position_lat IS NOT NULL
        AND (lr.t IS NULL OR p.insert_time > lr.t)
    ),
    session_start AS (
      SELECT GREATEST(
        COALESCE(lr.t, 0),
        COALESCE(fb.t, ${NEVER_SENTINEL}::bigint),
        COALESCE(fg.t, ${NEVER_SENTINEL}::bigint)
      ) AS t
      FROM last_ready lr, first_bite_ok fb, first_gps fg
    )
    SELECT
      s.equipment_number,
      s.vulnerability_state,
      s.originator_id,
      s.originator_charge_type_id,
      ct.short_name AS originator_charge_short_name,
      s.insert_time
    FROM ${schema}.rec_equipment_state s
    LEFT JOIN pdm.pdm_charge_type ct
           ON ct.id = s.originator_charge_type_id
    CROSS JOIN session_start ss
    WHERE (s.equipment_number = $1 OR s.originator_id = $1)
      AND (s.originator_id IS NULL OR s.originator_id NOT IN (${IGNORED_ORIGINATOR_IDS.join(',')}))
      AND (s.vulnerability_state IS NULL OR s.vulnerability_state NOT IN (${READY_VULNERABILITY_STATES.join(',')}))
      AND s.insert_time > ss.t
    ORDER BY s.insert_time DESC
    LIMIT ${HIT_HISTORY_LIMIT}
  `;

  try {
    const { rows } = await getPool().query(sql, [eq]);
    res.json(
      rows.map((r) => {
        const caused = r.originator_id === eq && r.equipment_number !== eq;
        return {
          equipmentNumber: r.equipment_number,
          originatorId: r.originator_id,
          caused,
          vulnerabilityState: r.vulnerability_state,
          vulnerabilityStateLabel: hpFromVulnerabilityState(r.vulnerability_state).status,
          originatorChargeShortName: r.originator_charge_short_name,
          insertTime: Number(r.insert_time),
        };
      })
    );
  } catch (err) {
    res.status(500).json({ error: err.message, schema });
  }
});

module.exports = router;
