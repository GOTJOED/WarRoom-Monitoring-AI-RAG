// routes/stats.js
// POST /api/exercise/:id/stats/start — begin recording (idempotent if already recording)
// POST /api/exercise/:id/stats/stop  — stop recording; computes+stores stats ONLY if
//                                       the session lasted >= MIN_DURATION_MS, otherwise
//                                       silently restarts the recording clock
// GET  /api/exercise/:id/stats       — read-only: current session state + last computed
//                                       result. Pure JSON-file read, ZERO DB queries —
//                                       safe to call as often as the stats page wants.

const express = require('express');
const { getSession, persist } = require('../stats/store');
const { computeStats } = require('../services/statsAggregate');
const { getConfig } = require('../config/config');
const { rosterFor } = require('../config/roster');

const router = express.Router();

const MIN_DURATION_MS = 10 * 60 * 1000; // 10 minutes

router.post('/api/exercise/:id/stats/start', (req, res) => {
  const session = getSession(req.params.id);
  if (!session.recording) {
    session.recording = true;
    session.startTime = Date.now();
    persist();
  }
  res.json({ ok: true, recording: true, startTime: session.startTime });
});

router.post('/api/exercise/:id/stats/stop', async (req, res) => {
  const session = getSession(req.params.id);
  if (!session.recording || !session.startTime) {
    return res.status(400).json({ ok: false, error: 'Not currently recording for this exercise.' });
  }

  const stopTime = Date.now();
  const elapsed = stopTime - session.startTime;

  if (elapsed < MIN_DURATION_MS) {
    // Too short to count — restart the clock rather than fully stopping,
    // per spec ("otherwise stopping confirms restarting recording").
    session.startTime = Date.now();
    persist();
    return res.json({
      ok: true,
      restarted: true,
      reason: `Session was ${(elapsed / 1000).toFixed(0)}s — minimum is ${MIN_DURATION_MS / 60000} minutes. Recording restarted.`,
      startTime: session.startTime,
    });
  }

  try {
    const cfg = getConfig();
    const ex = rosterFor(req.params.id);
    const result = await computeStats(req.params.id, cfg, ex, session.startTime, stopTime);

    session.recording = false;
    session.lastResult = result;
    session.lastComputedAt = Date.now();
    session.lastWindow = { start: session.startTime, stop: stopTime };
    session.startTime = null;
    persist();

    res.json({ ok: true, restarted: false, result });
  } catch (err) {
    // Computation failed — leave the session as still-recording rather than
    // silently discarding an otherwise-valid window; the operator can
    // retry Stop.
    res.status(500).json({ ok: false, error: err.message });
  }
});

router.get('/api/exercise/:id/stats', (req, res) => {
  const session = getSession(req.params.id);
  res.json({
    recording: session.recording,
    startTime: session.startTime,
    lastResult: session.lastResult,
    lastComputedAt: session.lastComputedAt,
    lastWindow: session.lastWindow,
  });
});

module.exports = router;
