// routes/config.js
// GET/POST /api/config

const express = require('express');
const { getConfig, setConfig, saveConfig } = require('../config/config');
const { buildPool, startHealthLoop } = require('../db/pool');

const router = express.Router();

router.get('/api/config', (req, res) => {
  const safeCopy = JSON.parse(JSON.stringify(getConfig()));
  if (safeCopy.db) safeCopy.db.password = safeCopy.db.password ? '••••••••' : '';
  res.json(safeCopy);
});

router.post('/api/config', (req, res) => {
  try {
    const incoming = req.body;
    const current = getConfig();
    const merged = { ...current, ...incoming };

    if (incoming.db && incoming.db.password === '••••••••') {
      merged.db.password = current.db.password;
    }

    setConfig(merged);
    saveConfig(merged);
    buildPool(merged);
    startHealthLoop(merged);

    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

module.exports = router;
