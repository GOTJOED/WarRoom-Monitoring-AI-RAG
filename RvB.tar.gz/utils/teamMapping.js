// utils/teamMapping.js
// Fixed party_id -> team mapping, per spec: 1 = OC, 2 = RED, 3 = BLUE.
// This REPLACES the old configurable config.teamMapping.blueParty/redParty
// scheme for automatic (non-manual-roster) team classification.
// Manual roster overrides (blue/red only) still take priority over this.

const PARTY_TEAM_MAP = { 1: 'oc', 2: 'red', 3: 'blue' };

function teamFromPartyId(partyId) {
  return PARTY_TEAM_MAP[partyId] || 'unknown';
}

module.exports = { PARTY_TEAM_MAP, teamFromPartyId };
