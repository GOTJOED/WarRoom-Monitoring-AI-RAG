// utils/constants.js
// Shared across db/players.js (live dashboard GPS check) and
// services/statsAggregate.js (historical GPS-coverage %) so both use the
// exact same "no GPS" threshold.
const GPS_TIMEOUT_SECONDS = 11 * 60;

module.exports = { GPS_TIMEOUT_SECONDS };
