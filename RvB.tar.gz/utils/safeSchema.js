// utils/safeSchema.js
// Validates an exercise id before it's interpolated into a SQL FROM clause
// as a schema name (e.g. `ex_230`). This is the one place raw string
// interpolation touches SQL, so it's guarded strictly: digits only.

function safeExerciseSchema(exerciseId) {
  if (!/^\d+$/.test(String(exerciseId))) {
    throw new Error('Invalid exercise id');
  }
  return `ex_${exerciseId}`;
}

module.exports = { safeExerciseSchema };
