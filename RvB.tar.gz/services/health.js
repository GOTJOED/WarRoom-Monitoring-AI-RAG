// services/health.js
//
// HP bars are now derived DIRECTLY from the raw integer
// rec_equipment_state.vulnerability_state value, via a FIXED mapping (no
// longer configurable through config.json's hpStateMap — that key is now
// unused; safe to remove from config.json, not urgent). The join to
// pdm.pdm_vulnerability_state (for the text name) has been dropped from
// db/players.js's query entirely — no longer needed.
//
// *** FLAGGED ASSUMPTION: the spec listed "0 = bars" with no bar count
// given for vulnerability_state 0 (Combat Ready). Inferred as 4 bars
// (full health), matching Combat Ready being the healthiest state and
// consistent with states 6/11 (also undamaged-equivalent) mapping to 4.
// Confirm/correct if 0 should be something else. ***
//
// NearMiss (10) is intentionally included here at 3 bars, same as before —
// db/players.js still derives its separate `nearMiss` display flag
// (appends " (Near Miss)" in the UI) directly from the raw integer
// (vulnerability_state === 10) rather than from a joined name string now.
const VULN_STATE_TO_BARS = {
  0: 4,  // Combat Ready         (ASSUMED — see note above)
  1: 3,  // Light Damage
  2: 2,  // Medium Damage
  3: 1,  // Heavy Damage
  4: 0,  // Mobility Kill         -> Killed
  6: 4,  // Weapon System Damage
  8: 0,  // Catastrophic Kill     -> Killed
  10: 3, // Near Miss
  11: 4, // Hit with No Effect
};

function barColorClass(bars) {
  if (bars >= 4) return 'hp-green';
  if (bars === 3) return 'hp-yellow';
  if (bars === 2) return 'hp-orange';
  if (bars === 1) return 'hp-red';
  return 'hp-killed';
}

// Backend status stays exactly 'Ready' | 'Wounded' | 'Killed' | null.
// The Human="Killed" / Apache+Vehicle="Catastrophic Killed" display-text
// split is unaffected by this change — it's still handled entirely by
// dashboard.html's effectiveStatusKey()/typeClass, unchanged.
function statusFromBars(bars) {
  if (bars === 4) return 'Ready';
  if (bars === 0) return 'Killed';
  return 'Wounded';
}

function hpFromVulnerabilityState(vulnerabilityState) {
  if (vulnerabilityState === null || vulnerabilityState === undefined) {
    return { bars: 4, colorClass: 'hp-green', status: 'Ready', matched: true };
  }
  const bars = VULN_STATE_TO_BARS[vulnerabilityState];
  if (bars === undefined) {
    return { bars: null, colorClass: 'hp-unknown', status: 'Unknown (' + vulnerabilityState + ')', matched: false };
  }
  return { bars, colorClass: barColorClass(bars), status: statusFromBars(bars), matched: true };
}

module.exports = { hpFromVulnerabilityState, barColorClass, statusFromBars };
