// services/chargeType.js
// pdm.pdm_charge_type cache (chargeTypeId -> name).
// Static-ish reference table; cached briefly to keep DB load negligible —
// this is queried once and reused across the whole poll cycle instead of
// joining it in on every request.
//
// NOTE: switched from `short_name` to `name` per the latest weapons-box
// spec (Charge Type column now shows the full name, not the short form).

const { getPool } = require('../db/pool');

let chargeTypeCache = { map: {}, fetchedAt: 0 };
const CHARGE_TYPE_TTL_MS = 5 * 60 * 1000; // 5 minutes

async function getChargeTypeMap() {
  const now = Date.now();
  if (now - chargeTypeCache.fetchedAt < CHARGE_TYPE_TTL_MS && Object.keys(chargeTypeCache.map).length) {
    return chargeTypeCache.map;
  }
  try {
    const { rows } = await getPool().query('SELECT id, name FROM pdm.pdm_charge_type');
    const map = {};
    rows.forEach((r) => { map[r.id] = r.name; });
    chargeTypeCache = { map, fetchedAt: now };
    return map;
  } catch (err) {
    return chargeTypeCache.map;
  }
}

module.exports = { getChargeTypeMap };
