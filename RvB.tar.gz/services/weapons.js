// services/weapons.js
//
// Confirmed against real data (ex_230 sample):
//   rec_equipment_gear_assignment.gears =
//     [{gearId, gearTypeId, chargeCounting}, ...]
//   rec_equipment_gear_charge_state.charge (per row, per gear) =
//     [{gearId, remain, gearTypeId, chargeTypeId}]
// gearId is a real shared unique key present in both sources — a specific
// `gears` entry is paired with its charge data by gearId, not positionally.
// This correctly handles a player carrying two weapons of the identical
// gearTypeId.
//
// Source of the weapon LIST: rec_equipment_gear_assignment.gears (latest
// row per equipment_number, see db/players.js assignment_latest CTE).
//   - name = pdm.pdm_gear_type.name, matched on gearTypeId
//
// Source of TOTAL ammo + chargeTypeId: chargeMap, built in db/players.js by
// unnesting rec_equipment_gear_charge_state.charge and taking the latest
// entry per (equipment_number, gearId) — because a single charge-state row
// only ever carries ONE gear's data, not a full per-equipment snapshot.
// total = that entry's `remain` field (named "remain" in the source but
// represents the magazine/supply TOTAL here, not the current remaining
// count). Keyed as `${equipmentNumber}|${gearId}`.
//   - chargeTypeName = pdm.pdm_charge_type.name, matched on chargeTypeId
//
// Source of REMAINING (current) ammo: rec_equipment_gear_event.charge_remain,
// matched by (equipment_number, charge_gear_type_id) — looked up via
// `remainingMap`, built once per /summary request from a single query over
// the whole exercise (see db/players.js), keyed as
// `${equipmentNumber}|${gearTypeId}`.
// NOTE: this table has no gearId column, so two identical-type weapons on
// one player will show the same `remaining` value for both — a source-data
// limitation, not something this code can disambiguate.

function normalizeGearsArray(json) {
  let items = [];
  if (Array.isArray(json)) {
    items = json;
  } else if (json && typeof json === 'string') {
    try { items = JSON.parse(json); } catch { items = []; }
  }
  if (!Array.isArray(items)) items = [];

  return items.filter((it) => it && typeof it === 'object' && it.gearTypeId != null);
}

function buildWeapons(assignmentGearsJson, equipmentNumber, gearTypeMap, chargeTypeMap, remainingMap, chargeMap) {
  const assignedGears = normalizeGearsArray(assignmentGearsJson);

  return assignedGears.map(({ gearId, gearTypeId }) => {
    const chargeEntry = chargeMap.get(`${equipmentNumber}|${gearId}`) || null;
    const chargeTypeId = chargeEntry ? chargeEntry.chargeTypeId : null;
    const total = chargeEntry ? chargeEntry.total : null;

    const remainKey = `${equipmentNumber}|${gearTypeId}`;
    // No rec_equipment_gear_event rows yet for this gear (freshly assigned/
    // resupplied, nothing fired since) means nothing to report as "spent" —
    // remaining defaults to the just-loaded total rather than showing blank.
    const remaining = remainingMap.has(remainKey) ? remainingMap.get(remainKey) : total;

    return {
      gearTypeId,
      chargeTypeId,
      name: (gearTypeId != null && gearTypeMap[gearTypeId]) ? gearTypeMap[gearTypeId] : 'Unknown Gear',
      chargeTypeName: (chargeTypeId != null && chargeTypeMap[chargeTypeId]) ? chargeTypeMap[chargeTypeId] : 'Unknown Charge',
      remaining,
      total,
    };
  });
}

module.exports = { buildWeapons };
