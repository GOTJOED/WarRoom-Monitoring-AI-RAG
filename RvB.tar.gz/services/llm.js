// services/llm.js
// Integrated JARVIS.llamafile RAG proxy, with a deterministic rule-based
// fallback used whenever the local llamafile server is unreachable.
//
// getLlmReply(message, context, config) -> { reply, source, contextUsed }

function buildContext(context) {
  const counts = context?.counts || { blueTotal: 0, blueAlive: 0, redTotal: 0, redAlive: 0 };
  const blue = context?.blue || [];
  const red = context?.red || [];
  const unknown = context?.unknownTeam || [];
  const allPlayers = [...blue, ...red, ...unknown];

  const playerDetails = allPlayers.length > 0
    ? allPlayers.map(p =>
        `- Operator #${p.equipmentNumber} (${p.team.toUpperCase()}): Status=${p.status || 'Unknown'}, HP=${p.healthBars ?? 'N/A'}/4, Ammo=${p.ammo ?? 'N/A'}, BITE=${p.biteLabel || 'N/A'}${p.notInExercise ? ' [NOT IN EXERCISE]' : ''}`
      ).join('\n')
    : 'No active operator telemetry loaded.';

  const contextText = `
EXERCISE ID: ${context?.exerciseId || 'N/A'}
LIVE SCOREBOARD COUNTS:
- Blue Team: ${counts.blueAlive} alive / ${counts.blueTotal} total (Killed: ${counts.blueTotal - counts.blueAlive})
- Red Team: ${counts.redAlive} alive / ${counts.redTotal} total (Killed: ${counts.redTotal - counts.redAlive})

OPERATOR TELEMETRY ROSTER:
${playerDetails}
`.trim();

  return { counts, allPlayers, contextText };
}

function buildSystemPrompt(contextText) {
  return `You are AI Assistant, an air-gapped tactical monitor for Military exercise.
STRICT OPERATIONAL DIRECTIVES:
1. Answer user questions ONLY using the REAL-TIME DASHBOARD DATA provided below.
2. Under no circumstances invent, speculate, or extrapolate facts not present in the data.
3. If asked a question that cannot be answered from the data, state clearly: "That information is not available in current dashboard telemetry."
4. Be concise, direct, and tactical.

=== REAL-TIME DASHBOARD DATA ===
${contextText}
================================`;
}

function ruleFallback(message, counts, allPlayers) {
  const l = String(message).toLowerCase();
  let reply = '';

  if (l.includes('blue') && l.includes('alive')) {
    reply = `🔵 BLUE team: ${counts.blueAlive}/${counts.blueTotal} alive (Killed: ${counts.blueTotal - counts.blueAlive}).`;
  } else if (l.includes('red') && l.includes('alive')) {
    reply = `🔴 RED team: ${counts.redAlive}/${counts.redTotal} alive (Killed: ${counts.redTotal - counts.redAlive}).`;
  } else if (l.includes('wounded')) {
    const wounded = allPlayers.filter(p => p.status === 'Wounded');
    reply = wounded.length
      ? `🟠 Wounded operators (${wounded.length}): ` + wounded.map(p => `#${p.equipmentNumber} (${p.team}) HP:${p.healthBars}/4`).join(', ')
      : 'No wounded operators.';
  } else if (l.includes('low ammo') || (l.includes('ammo') && !l.includes('how'))) {
    const low = allPlayers.filter(p => p.ammo !== null && p.ammo < 30).sort((a, b) => a.ammo - b.ammo);
    reply = low.length
      ? `⚠️ Low ammo (<30): ` + low.map(p => `#${p.equipmentNumber} (${p.team}) Ammo:${p.ammo}`).join(', ')
      : 'No low ammo reported.';
  } else if (l.includes('bite')) {
    const err = allPlayers.filter(p => p.biteOk === false).length;
    const ok = allPlayers.filter(p => p.biteOk === true).length;
    const nodata = allPlayers.filter(p => p.biteOk === null).length;
    reply = `BITE Status — OK:${ok} | Error:${err} | No Data:${nodata}`;
  } else if (l.includes('killed')) {
    const killed = allPlayers.filter(p => p.status === 'Killed');
    reply = killed.length
      ? `💀 Killed operators (${killed.length}): ` + killed.map(p => `#${p.equipmentNumber} (${p.team})`).join(', ')
      : 'No killed operators.';
  } else {
    reply = `[Rule Fallback] Blue: ${counts.blueAlive}/${counts.blueTotal} alive | Red: ${counts.redAlive}/${counts.redTotal} alive.`;
  }

  return reply;
}

async function getLlmReply(message, context, config) {
  const { counts, allPlayers, contextText } = buildContext(context);
  const systemPrompt = buildSystemPrompt(contextText);

  const llmUrl = (config.llm && config.llm.url) || process.env.LLM_URL || 'http://127.0.0.1:3100/v1/chat/completions';

  try {
    const fetch = (await import('node-fetch')).default || global.fetch;
    const payload = {
      model: (config.llm && config.llm.model) || 'Qwen2.5-Coder-1.5B',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: message }
      ],
      temperature: 0.1,
      max_tokens: 350,
      stream: false
    };

    const response = await fetch(llmUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (response.ok) {
      const data = await response.json();
      const reply = data.choices?.[0]?.message?.content || data.content || 'No reply received from JARVIS.';
      return { reply, source: 'llamafile', contextUsed: counts };
    }
  } catch (err) {
    console.error('[JARVIS Proxy Warning] llamafile server connection failed:', err.message);
  }

  // Fallback rule engine (active if llamafile server is offline)
  const reply = ruleFallback(message, counts, allPlayers);
  return { reply, source: 'rule-fallback', contextUsed: counts };
}

module.exports = { getLlmReply };
