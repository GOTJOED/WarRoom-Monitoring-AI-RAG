// services/gearType.js
// pdm.pdm_gear_type cache (gearTypeId -> name).
// Static-ish reference table; cached briefly to keep DB load negligible,
// same pattern as services/chargeType.js.

const { getPool } = require('../db/pool');

let gearTypeCache = { map: {}, fetchedAt: 0 };
const GEAR_TYPE_TTL_MS = 5 * 60 * 1000; // 5 minutes

async function getGearTypeMap() {
  const now = Date.now();
  if (now - gearTypeCache.fetchedAt < GEAR_TYPE_TTL_MS && Object.keys(gearTypeCache.map).length) {
    return gearTypeCache.map;
  }
  try {
    const { rows } = await getPool().query('SELECT id, name FROM pdm.pdm_gear_type');
    const map = {};
    rows.forEach((r) => { map[r.id] = r.name; });
    gearTypeCache = { map, fetchedAt: now };
    return map;
  } catch (err) {
    return gearTypeCache.map;
  }
}

module.exports = { getGearTypeMap };
