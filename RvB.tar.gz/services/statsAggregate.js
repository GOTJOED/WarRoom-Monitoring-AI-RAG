// services/statsAggregate.js
//
// Computes individual/team/overall statistics for a recorded window
// [startTime, stopTime] (both epoch-ms, matching the bigint-ms insert_time
// convention used everywhere else in this codebase).
//
// *** RUNS EXACTLY ONCE PER RECORDED SESSION — ONLY WHEN "STOP EXERCISE" IS
// PRESSED (see routes/stats.js). NEVER called on a poll, on page load, or
// on viewing the stats page. This is the one place in the whole app that
// deliberately scans full history over a time window instead of "latest
// row per equipment_number" — that's only acceptable because it's a rare,
// deliberate, one-time action, not a repeating one. The computed result is
// stored (stats/store.js) and the stats page only ever reads that stored
// result — zero DB load to VIEW stats, only to RECORD them. ***
//
// Query count: 8 queries total, all run once via Promise.all. Each is a
// straightforward WHERE insert_time BETWEEN ... scan (or a DISTINCT ON
// "latest at-or-before start" lookup) — same indexes already recommended
// in sql/create-indexes.sql cover these access patterns (equipment_number,
// [key,] insert_time DESC/ASC), no new indexes needed.
//
// *** FLAGGED ASSUMPTIONS — verify against real data: ***
// 1. rec_equipment_position lon/lat are plain WGS84 decimal degrees
//    (standard GPS convention) — distance uses the haversine formula on
//    that assumption. If these are actually projected/UTM coordinates or
//    scaled integers, distance-traveled will be wrong. Sanity-check the
//    first computed distance against a known unit's actual movement.
// 2. Rounds-fired is computed as the sum of DECREASES in charge_remain
//    between consecutive in-window gear_event rows per
//    (equipment_number, charge_gear_type_id) — increases are treated as
//    resupply refills and excluded, never counted as negative shots. The
//    very first in-window row for a given weapon has no prior in-window
//    value to diff against, so shots fired in the small gap between the
//    true window start and that first recorded row are not counted —
//    likely negligible during active engagement, but flagging the gap.
// 3. "Resupply count" per weapon is approximated as the count of
//    rec_equipment_gear_charge_state rows in-window for that
//    equipment_number (not narrowed to the specific gear/chargeType) —
//    correct when a player has one weapon, an overcount if multiple
//    weapons resupply independently within the same window. Precise
//    per-weapon counting would need the same jsonb-unnest treatment as
//    db/players.js's fetchChargeMap; skipped here to keep this already
//    large query set manageable — flag if per-weapon precision matters.

const { getPool } = require('../db/pool');
const { safeExerciseSchema } = require('../utils/safeSchema');
const { hpFromVulnerabilityState } = require('./health');
const { teamFromPartyId } = require('../utils/teamMapping');
const { GPS_TIMEOUT_SECONDS } = require('../utils/constants');

function classFromTypeClassId(typeClassId) {
  switch (typeClassId) {
    case 3: return 'Human';
    case 5: return 'Apache';
    case 7:
    case 8: return 'Vehicle';
    default: return null;
  }
}

// Standard haversine great-circle distance, in meters. Assumes plain WGS84
// decimal-degree lon/lat (flagged assumption #1 above).
function haversineMeters(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function groupBy(rows, key) {
  const map = new Map();
  rows.forEach((r) => {
    const k = r[key];
    if (!map.has(k)) map.set(k, []);
    map.get(k).push(r);
  });
  return map;
}

async function computeStats(exerciseId, cfg, ex, startTime, stopTime) {
  const schema = safeExerciseSchema(exerciseId);
  const pool = getPool();
  const windowMs = stopTime - startTime;

  const [
    rosterRes,
    stateBeforeRes, stateWindowRes,
    biteBeforeRes, biteWindowRes,
    positionRes,
    gearEventRes,
    chargeStateCountRes,
  ] = await Promise.all([
    pool.query(`
      SELECT pp.equipment_number, pp.party_id, pp.designator, pp.tactical_identifier,
             pty.name AS type_name, pty.type_class_id
      FROM ${schema}.ppm_participant pp
      LEFT JOIN ppm.ppm_type pty ON pty.id = pp.type_id
    `),
    pool.query(`
      SELECT DISTINCT ON (equipment_number) equipment_number, vulnerability_state
      FROM ${schema}.rec_equipment_state
      WHERE insert_time <= ${startTime}
      ORDER BY equipment_number, insert_time DESC
    `),
    pool.query(`
      SELECT equipment_number, vulnerability_state, insert_time
      FROM ${schema}.rec_equipment_state
      WHERE insert_time > ${startTime} AND insert_time <= ${stopTime}
      ORDER BY equipment_number, insert_time ASC
    `),
    pool.query(`
      SELECT DISTINCT ON (equipment_number) equipment_number, config_error
      FROM ${schema}.rec_equipment_bite
      WHERE insert_time <= ${startTime}
      ORDER BY equipment_number, insert_time DESC
    `),
    pool.query(`
      SELECT equipment_number, config_error, insert_time
      FROM ${schema}.rec_equipment_bite
      WHERE insert_time > ${startTime} AND insert_time <= ${stopTime}
      ORDER BY equipment_number, insert_time ASC
    `),
    pool.query(`
      SELECT equipment_number, position_position_lon, position_position_lat, insert_time
      FROM ${schema}.rec_equipment_position
      WHERE insert_time > ${startTime} AND insert_time <= ${stopTime}
      ORDER BY equipment_number, insert_time ASC
    `),
    pool.query(`
      SELECT equipment_number, charge_gear_type_id, charge_remain, insert_time
      FROM ${schema}.rec_equipment_gear_event
      WHERE insert_time > ${startTime} AND insert_time <= ${stopTime}
      ORDER BY equipment_number, charge_gear_type_id, insert_time ASC
    `),
    pool.query(`
      SELECT equipment_number, COUNT(*) AS resupply_count
      FROM ${schema}.rec_equipment_gear_charge_state
      WHERE insert_time > ${startTime} AND insert_time <= ${stopTime}
      GROUP BY equipment_number
    `),
  ]);

  const stateBeforeMap = new Map(stateBeforeRes.rows.map(r => [r.equipment_number, r.vulnerability_state]));
  const stateWindowByEq = groupBy(stateWindowRes.rows, 'equipment_number');
  const biteBeforeMap = new Map(biteBeforeRes.rows.map(r => [r.equipment_number, r.config_error]));
  const biteWindowByEq = groupBy(biteWindowRes.rows, 'equipment_number');
  const positionByEq = groupBy(positionRes.rows, 'equipment_number');
  const gearEventByEq = groupBy(gearEventRes.rows, 'equipment_number');
  const resupplyCountMap = new Map(chargeStateCountRes.rows.map(r => [r.equipment_number, Number(r.resupply_count)]));

  const individual = rosterRes.rows.map((p) => {
    const eq = p.equipment_number;

    // --- Health/status timeline: time-of-death, damage-event count, near-miss ---
    const beforeState = stateBeforeMap.has(eq) ? stateBeforeMap.get(eq) : null;
    const windowStates = stateWindowByEq.get(eq) || [];
    let timeOfDeath = null;
    let damageEventCount = windowStates.length;
    let nearMissCount = windowStates.filter(r => r.vulnerability_state === 10).length;

    if (beforeState !== null && hpFromVulnerabilityState(beforeState).bars === 0) {
      timeOfDeath = startTime; // already dead going into the recorded window
    }
    if (timeOfDeath === null) {
      const deathRow = windowStates.find(r => hpFromVulnerabilityState(r.vulnerability_state).bars === 0);
      if (deathRow) timeOfDeath = Number(deathRow.insert_time);
    }
    const finalState = windowStates.length ? windowStates[windowStates.length - 1].vulnerability_state : beforeState;
    const finalHp = hpFromVulnerabilityState(finalState);
    const survivedMs = (timeOfDeath !== null ? timeOfDeath : stopTime) - startTime;

    // --- BITE uptime %: duration-weighted across the before-state + in-window rows ---
    let biteOkMs = 0, biteErrMs = 0, biteKnownMs = 0;
    {
      let cursorTime = startTime;
      let cursorOk = biteBeforeMap.has(eq) ? (biteBeforeMap.get(eq) === false) : null;
      const rows = biteWindowByEq.get(eq) || [];
      rows.forEach((r) => {
        const t = Number(r.insert_time);
        if (cursorOk !== null) {
          const dt = t - cursorTime;
          if (cursorOk) biteOkMs += dt; else biteErrMs += dt;
          biteKnownMs += dt;
        }
        cursorTime = t;
        cursorOk = (r.config_error === false);
      });
      if (cursorOk !== null) {
        const dt = stopTime - cursorTime;
        if (cursorOk) biteOkMs += dt; else biteErrMs += dt;
        biteKnownMs += dt;
      }
    }
    const biteUptimePct = biteKnownMs > 0 ? Math.round((biteOkMs / biteKnownMs) * 1000) / 10 : null;

    // --- GPS coverage %: fraction of window "covered" by a fresh fix ---
    let gpsCoveredMs = 0;
    {
      const rows = positionByEq.get(eq) || [];
      const timeoutMs = GPS_TIMEOUT_SECONDS * 1000;
      let prevTime = null;
      rows.forEach((r) => {
        const t = Number(r.insert_time);
        if (prevTime !== null) {
          gpsCoveredMs += Math.min(t - prevTime, timeoutMs);
        } else {
          gpsCoveredMs += Math.min(t - startTime, timeoutMs);
        }
        prevTime = t;
      });
      if (prevTime !== null) {
        gpsCoveredMs += Math.min(stopTime - prevTime, timeoutMs);
      }
    }
    const gpsCoveragePct = windowMs > 0 ? Math.round((Math.min(gpsCoveredMs, windowMs) / windowMs) * 1000) / 10 : null;

    // --- Distance traveled (meters), consecutive in-window fixes only ---
    let distanceMeters = 0;
    {
      const rows = (positionByEq.get(eq) || []).filter(r => r.position_position_lat != null && r.position_position_lon != null);
      for (let i = 1; i < rows.length; i++) {
        distanceMeters += haversineMeters(
          Number(rows[i - 1].position_position_lat), Number(rows[i - 1].position_position_lon),
          Number(rows[i].position_position_lat), Number(rows[i].position_position_lon)
        );
      }
    }

    // --- Rounds fired per weapon (sum of decreases only; resupply jumps excluded) ---
    let roundsFiredTotal = 0;
    const roundsByWeapon = {};
    {
      const rows = gearEventByEq.get(eq) || [];
      const byGear = groupBy(rows, 'charge_gear_type_id');
      byGear.forEach((gearRows, gearTypeId) => {
        let fired = 0;
        for (let i = 1; i < gearRows.length; i++) {
          const prev = Number(gearRows[i - 1].charge_remain);
          const curr = Number(gearRows[i].charge_remain);
          if (!isNaN(prev) && !isNaN(curr) && curr < prev) {
            fired += (prev - curr);
          }
        }
        roundsByWeapon[gearTypeId] = fired;
        roundsFiredTotal += fired;
      });
    }

    // Manual roster (blue/red only) overrides the fixed party_id mapping —
    // same precedence rule as db/players.js's shapePlayerBase.
    let team = teamFromPartyId(p.party_id);
    if (ex && ex.blue.includes(eq)) team = 'blue';
    else if (ex && ex.red.includes(eq)) team = 'red';

    return {
      equipmentNumber: eq,
      team,
      typeClass: classFromTypeClassId(p.type_class_id),
      designator: p.designator,
      tacticalIdentifier: p.tactical_identifier,
      typeName: p.type_name || 'Unknown',
      finalStatus: finalHp.status,
      finalHealthBars: finalHp.bars,
      timeOfDeath,
      survivedMs,
      damageEventCount,
      nearMissCount,
      biteUptimePct,
      gpsCoveragePct,
      distanceMeters: Math.round(distanceMeters),
      roundsFiredTotal,
      roundsByWeapon,
      resupplyCount: resupplyCountMap.get(eq) || 0,
    };
  });

  // --- Team rollups ---
  const teams = { blue: [], red: [], oc: [] };
  individual.forEach((p) => {
    if (teams[p.team]) teams[p.team].push(p);
  });

  function teamSummary(list) {
    if (!list.length) return null;
    const alive = list.filter(p => p.finalStatus !== 'Killed').length;
    const killed = list.length - alive;
    const uptimes = list.map(p => p.biteUptimePct).filter(v => v !== null);
    const firstCasualty = list.map(p => p.timeOfDeath).filter(v => v !== null).sort((a, b) => a - b)[0] || null;
    return {
      total: list.length,
      alive,
      killed,
      totalRoundsFired: list.reduce((s, p) => s + p.roundsFiredTotal, 0),
      totalDistanceMeters: Math.round(list.reduce((s, p) => s + p.distanceMeters, 0)),
      avgBiteUptimePct: uptimes.length ? Math.round((uptimes.reduce((a, b) => a + b, 0) / uptimes.length) * 10) / 10 : null,
      firstCasualtyMs: firstCasualty !== null ? (firstCasualty - startTime) : null,
    };
  }

  const team = {
    blue: teamSummary(teams.blue),
    red: teamSummary(teams.red),
    oc: teamSummary(teams.oc),
  };

  // --- Attrition curve: cumulative Blue/Red casualties sampled at 10 even buckets ---
  const BUCKET_COUNT = 10;
  const attrition = [];
  for (let i = 1; i <= BUCKET_COUNT; i++) {
    const bucketTime = startTime + Math.round((windowMs * i) / BUCKET_COUNT);
    attrition.push({
      t: bucketTime,
      blueKilled: teams.blue.filter(p => p.timeOfDeath !== null && p.timeOfDeath <= bucketTime).length,
      redKilled: teams.red.filter(p => p.timeOfDeath !== null && p.timeOfDeath <= bucketTime).length,
    });
  }

  // --- Overall ---
  const allKnownUptimes = individual.map(p => p.biteUptimePct).filter(v => v !== null);
  const allKnownGps = individual.map(p => p.gpsCoveragePct).filter(v => v !== null);
  const blueAlive = team.blue ? team.blue.alive : 0;
  const redAlive = team.red ? team.red.alive : 0;
  let winner = 'undetermined';
  if (blueAlive === 0 && redAlive === 0) winner = 'draw';
  else if (redAlive === 0) winner = 'blue';
  else if (blueAlive === 0) winner = 'red';
  else winner = blueAlive >= redAlive ? 'blue' : 'red';

  const overall = {
    windowStart: startTime,
    windowStop: stopTime,
    windowDurationMs: windowMs,
    participantCount: individual.length,
    totalKilled: individual.filter(p => p.finalStatus === 'Killed').length,
    totalRoundsFired: individual.reduce((s, p) => s + p.roundsFiredTotal, 0),
    totalDistanceMeters: Math.round(individual.reduce((s, p) => s + p.distanceMeters, 0)),
    fleetBiteUptimePct: allKnownUptimes.length ? Math.round((allKnownUptimes.reduce((a, b) => a + b, 0) / allKnownUptimes.length) * 10) / 10 : null,
    fleetGpsCoveragePct: allKnownGps.length ? Math.round((allKnownGps.reduce((a, b) => a + b, 0) / allKnownGps.length) * 10) / 10 : null,
    winner,
  };

  return { individual, team, attrition, overall };
}

module.exports = { computeStats };
