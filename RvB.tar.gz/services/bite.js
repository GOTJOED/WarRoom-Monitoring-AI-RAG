// services/bite.js
//
// BITE Cfg is now a 3-state value combining the raw BITE config_error flag
// with GPS freshness (noGps, computed in db/players.js from
// rec_equipment_position), per spec:
//   - config_error === false AND has fresh GPS (< 11 min)  -> "All OK w/ GPS"
//   - config_error === false AND no fresh GPS               -> "All OK, No GPS"
//   - config_error === true  (regardless of GPS)            -> "Error"
//   - config_error === null/undefined                       -> "No Data"
//
// NOTE: per spec, the original BITE ok/error determination now depends
// SOLELY on config_error — bite_errors is no longer consulted (previously
// it was ANDed in). This is an explicit, not inferred, change. bite_errors
// is still selected in db/players.js's SQL but is now unused dead weight —
// harmless, safe to drop from the SELECT later if you want the cleanup.
//
// *** FLAGGED GAP: the spec's 3 options only explicitly cover
// (error=true AND noGps=true) for "Error". The 4th combination
// (error=true AND noGps=false — has BITE errors but DOES have a fresh GPS
// fix) isn't named. Bucketed into "Error" here, since a unit with BITE
// errors reading as "OK" just because GPS is fresh would be misleading.
// Flag if that's not the intended behavior. ***
function biteStatus(configError, noGps) {
  if (configError === null || configError === undefined) {
    return { ok: null, label: 'No Data' };
  }
  const rawOk = configError === false;
  if (!rawOk) {
    return { ok: false, label: 'Error' };
  }
  return noGps
    ? { ok: true, label: 'All OK, No GPS' }
    : { ok: true, label: 'All OK w/ GPS' };
}

module.exports = { biteStatus };
